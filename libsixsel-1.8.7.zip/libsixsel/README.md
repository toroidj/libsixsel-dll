libsixel.dll
============

libsixel.dll is libsixel 1.8.7 [https://github.com/saitoha/libsixel/](https://github.com/saitoha/libsixel/) DLL for Windows x86/x64, and built with option '-with-png=no --with-jpeg=no --with-libcurl=no --enable-python=no'.

libsixel provides encoder/decoder implementation for DEC SIXEL graphics, and
some converter programs.


## Support

This software is provided "as is" without express or implied warranty.


## License

See libsixel's License [https://github.com/saitoha/libsixel/](https://github.com/saitoha/libsixel/).
